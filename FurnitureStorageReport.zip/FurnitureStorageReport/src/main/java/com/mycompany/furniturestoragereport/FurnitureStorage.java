/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.furniturestoragereport;
//This is the class that Implements IFurnitureStorage
//The calculations will be held here from IFurnitureStorage

public class FurnitureStorage implements IFurnitureStorage {
    
//Step 1: GetTotalCustomers
//Using a for-each loop    
    public int GetTotalCustomers(int[] furnitureStorage){
        int total = 0;
        for (int allFurniture : furnitureStorage){
            total += allFurniture;
        }
        return total; //Returns the final total
    }
    
//Step 2: GetAverageCustomers.
//Calculating the average sale value.
    public double GetAverageCustomers(int[] furnitureStorage){
        return (double) GetTotalCustomers(furnitureStorage) / furnitureStorage.length;
        
    }
    
//Step 3: GetMostPopularTown.
//Finding the most popular toen in the array.
    public int GetMostPopularTown(int[] furnitureStorage){
        int max = furnitureStorage[0];
        for (int allFurniture : furnitureStorage){
            if (allFurniture > max) max = allFurniture;
        }
        return max; // returns the largest sale
        
    }
    
//Step 4: GetLeastPopularTown
//Find the least popular town in the array.  
    public int GetLeastPopularTown(int[] furnitureStorage){
      int min = furnitureStorage[0];
      for (int allFurniture : furnitureStorage){
          if (allFurniture < min) min = allFurniture;
          
      }
      return min; //returns the least popular town
    }

    @Override
    public int GetTotalCustomers() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public double GetAverageCustomers() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String GetMostPopularTown() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public String GetLeastPopularTown() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

