/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package com.mycompany.furniturestoragereport;
//The CLASS INTERFACE that is IMPLEMENTED by FurnitureStorage
//The headings here are carries & calculated in FurnitureStorage

public interface IFurnitureStorage {
    int GetTotalCustomers();
    double GetAverageCustomers();
    String GetMostPopularTown();
    String GetLeastPopularTown();
    }
