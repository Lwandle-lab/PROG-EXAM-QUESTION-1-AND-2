/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestoragereport;

//The MAIN class for the whole Java Program
public class FurnitureStorageReport {
    public static void main(String[] args) {
    //Incorporating the TWO Dimensional Array 
        int[][] agencyData = {
            {90, 15, 50}, //Year 1
            {125, 55, 91}, //Year 2
        };
        
    //Flattening  the 2D array into 1 Dimensional for calculations    
    //Also calculating the total, the average, least number of customers during the two year period  
        int furniture = new int [agencyData.length * agencyData[0].length];
            int index = 0;
            for (int[] year : agencyData){
                for (int item : year){
                    furniture[index++] = item;
                }
            }
            
    //Creating the FurnitureStorage object
    FurnitureStorage fs = new FurnitureStorage();
    
    
    //Displaying the Storage Display
    System.out.println("FURNITURE STORAGE REPORT - 2026");
    System.out.println("***************************");
    System.out.println("TOTAL CUSTOMERS: " + fs.GetTotalCustomers(furniture));
    System.out.println("AVERAGE CUSTOMERS: " + fs.GetAverageCustomers(furniture));
    System.out.println("TOWN WITH MOST CUSTOMERS: " + fs.GetMostPopularTown(furniture));
    System.out.println("TOWN WITH LEAST CUSTOMERS: " + fs.GetLeastPopularTown(furniture));
    System.out.println("***************************");
    }
}
