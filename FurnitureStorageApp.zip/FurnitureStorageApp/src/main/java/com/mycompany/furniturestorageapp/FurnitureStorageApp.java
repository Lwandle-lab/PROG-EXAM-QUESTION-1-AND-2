/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.furniturestorageapp;
//The GUI application 

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class FurnitureStorageApp extends JFrame {
    private JTextArea txtDisplay;
    private JLabel iblYears;
    
    public static void main(String[] args) {
        
    }
}
